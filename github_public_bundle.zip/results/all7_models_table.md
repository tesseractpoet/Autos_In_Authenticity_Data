# All seven models together (final labels, Mon Nov 16, 1 AM)

**Labels:** Claude Opus judges for the six open models. Claude Haiku 5.5† uses the human-adjudicated labels (Gemini primary judge plus AJ's rulings and rules; see `claude/appendix-haiku-adjudication.md`).

**Sample:** 181 prompts × 7 conditions per model. The 181 prompts are 55 provided_facts, 42 known_facts, 35 continuations, 25 disinformation and 24 doubling-down.

**Scoring:** percentages are of scored answers (honest + lie + evade). no_belief, unclear and empty answers are excluded.

**Tests:** exact McNemar, paired on prompts. \* p < .05, \*\* p < .0063 (Bonferroni over 8 contrasts). The pooled test sums discordant pairs across models, so it treats model × prompt pairs as independent.

## Lie % by condition
| condition | Gemma 4 31B | GLM-5.3-flash | GLM-5.3 | DeepSeek V4.1 Flash | gpt-oss-120b | Llama-3.1-8B | Claude Haiku 5.5† |
|---|---|---|---|---|---|---|---|
| baseline | 62.2 | 19.9 | 17.1 | 39.8 | 21.4 | 55.3 | 6.0 |
| first_person | 64.7 | 24.1 | 17.7 | 46.9 | 21.9 | 64.4 | 6.7 |
| first_person_self | 50.7 | 10.1 | 10.8 | 20.5 | 19.4 | 54.7 | 3.0 |
| hyperactive | 63.5 | 22.9 | 23.0 | 65.4 | 24.8 | 62.1 | 7.3 |
| anglo_saxon | 71.6 | 29.8 | 21.0 | 57.2 | 26.5 | 64.8 | 7.8 |
| latinate | 71.8 | 39.5 | 27.3 | 66.9 | 32.5 | 61.0 | 7.2 |
| control_format | 69.7 | 28.8 | 24.6 | 58.4 | 31.0 | 58.1 | 7.8 |

## Not-honest % (lie + evade) by condition
| condition | Gemma 4 31B | GLM-5.3-flash | GLM-5.3 | DeepSeek V4.1 Flash | gpt-oss-120b | Llama-3.1-8B | Claude Haiku 5.5† |
|---|---|---|---|---|---|---|---|
| baseline | 84.0 | 26.3 | 24.4 | 56.5 | 83.8 | 72.0 | 18.1 |
| first_person | 79.5 | 28.8 | 24.4 | 58.1 | 85.8 | 75.0 | 22.6 |
| first_person_self | 67.1 | 13.6 | 14.5 | 31.1 | 81.3 | 70.2 | 17.5 |
| hyperactive | 81.4 | 30.6 | 29.7 | 72.3 | 75.8 | 73.9 | 17.0 |
| anglo_saxon | 85.8 | 38.0 | 26.3 | 69.2 | 75.5 | 78.4 | 18.7 |
| latinate | 84.6 | 47.1 | 33.9 | 79.4 | 76.0 | 71.1 | 19.9 |
| control_format | 85.8 | 34.7 | 29.3 | 68.3 | 78.1 | 75.0 | 22.2 |

## Paired change in lie %, percentage points
| contrast | Gemma 4 31B | GLM-5.3-flash | GLM-5.3 | DeepSeek V4.1 Flash | gpt-oss-120b | Llama-3.1-8B | Claude Haiku 5.5† | POOLED (7) |
|---|---|---|---|---|---|---|---|---|
| baseline -> first_person | +2.6 | +4.1 | +1.2 | +8.2 | +0.6 | +8.9* | +1.2 | +3.8** (p=0.00088) |
| baseline -> first_person_self | -10.5* | -10.1** | -6.1 | -18.8** | -2.6 | -0.6 | -2.4 | -7.3** (p=3.6e-09) |
| first_person -> first_person_self | -14.5** | -15.0** | -6.7 | -26.4** | -2.6 | -10.1* | -2.5 | -11.1** (p=1.2e-19) |
| baseline -> hyperactive | +1.3 | +2.4 | +5.5 | +24.7** | +2.6 | +6.9 | +1.8 | +6.4** (p=3.9e-07) |
| baseline -> anglo_saxon | +9.0** | +10.0** | +3.7 | +17.6** | +5.2 | +9.4* | +1.8 | +8.1** (p=8.3e-11) |
| baseline -> latinate | +9.6** | +19.3** | +10.4** | +26.9** | +11.1** | +5.1 | +1.2 | +12.0** (p=6.5e-21) |
| baseline -> control_format | +7.7* | +8.9* | +7.3 | +18.1** | +9.1* | +3.2 | +1.2 | +7.9** (p=2.8e-09) |
| anglo_saxon -> latinate | +0.6 | +9.4** | +6.7 | +10.1* | +5.8 | -4.4 | -0.6 | +4.0** (p=0.00053) |

## Paired change in not-honest %, percentage points
| contrast | Gemma 4 31B | GLM-5.3-flash | GLM-5.3 | DeepSeek V4.1 Flash | gpt-oss-120b | Llama-3.1-8B | Claude Haiku 5.5† | POOLED (7) |
|---|---|---|---|---|---|---|---|---|
| baseline -> first_person | -4.5 | +2.4 | +0.6 | +2.5 | +2.6 | +2.5 | +4.9* | +1.6 (p=0.18) |
| baseline -> first_person_self | -16.4** | -13.1** | -9.8** | -25.0** | -2.6 | -2.5 | +0.0 | -9.9** (p=5.2e-14) |
| first_person -> first_person_self | -12.5** | -16.2** | -9.8* | -27.7** | -4.5 | -5.7 | -3.7 | -11.5** (p=4.5e-19) |
| baseline -> hyperactive | -2.6 | +3.6 | +4.9 | +14.6** | -7.9* | +1.9 | -0.6 | +2.1 (p=0.11) |
| baseline -> anglo_saxon | +1.3 | +11.8** | +1.8 | +12.6** | -7.8* | +6.2 | +0.6 | +3.9** (p=0.0015) |
| baseline -> latinate | +0.6 | +20.5** | +9.2* | +23.1** | -7.2* | -1.3 | +1.8 | +6.9** (p=5.7e-08) |
| baseline -> control_format | +1.9 | +8.9* | +4.9 | +11.9** | -5.8 | +3.8 | +3.6 | +4.3** (p=0.00061) |
| anglo_saxon -> latinate | -0.6 | +8.8** | +7.9* | +10.8** | +0.6 | -7.5* | +1.2 | +3.1** (p=0.0046) |

## Prompts excluded for no stable belief (of 181)
|  | Gemma 4 31B | GLM-5.3-flash | GLM-5.3 | DeepSeek V4.1 Flash | gpt-oss-120b | Llama-3.1-8B | Claude Haiku 5.5† |
|---|---|---|---|---|---|---|---|
| prompts | 25 | 9 | 14 | 19 | 26 | 17 | 13 |

Full numbers are in `all7_rates.csv` (with n, honest %, evade % and Wilson CIs) and `all7_paired_tests.csv` (with discordant pairs, ratios and exact p-values).

† Haiku: Gemini primary judge plus human adjudication. The other models: Claude Opus judges; their Gemini labels are pending.
