# Figures (final labels, Mon Nov 16)

**Gallery with all 10 figures:** https://claude.ai/artifact/2aDwoE4d7yMGea5hzC9Ley. Each figure has a caption, and you can open and save the full-size PNG from there. SVG versions and the CSV behind every figure are in `sprint_figures.zip` and `epistemics_sprint_workspace.zip` (folder `figs/`).

Haiku (†) uses human-adjudicated labels (Gemini primary judge); the other models use Claude Opus judges. All intervals are 95% (Wilson for rates; bootstrap over prompts, 4,000 resamples, for paired changes).

| file | what it shows |
|---|---|
| fig7_whose_I_slope | Slope chart baseline → plain "I" → "as yourself", one line per model, pooled in black, with both pooled changes labeled |
| fig1_lie_rates | Lie % by condition; one panel per model; baseline dark, "as yourself" blue |
| fig1b_nothonest_rates | Not-honest % (lie + evade) by condition |
| fig2a_change_points | Paired change from baseline in points, per contrast, with pooled |
| fig2b_change_relative | Same as 2a, as a ratio to the model's own starting rate (log) |
| fig2c_nothonest_change_points | Paired change in not-honest % |
| fig5a_profile_points | Trendline profile: each model's change from baseline across conditions |
| fig5b_profile_relative | Trendline profile as ratios to baseline |
| fig6_three_conditions_by_type | Combined: baseline, plain first person and "as yourself" per model, one panel per scenario type |
| fig3_first_person_by_type | Plain first person vs baseline, by scenario type |
| fig4_as_yourself_by_type | "As yourself" vs baseline, by scenario type |
| fig4b_as_yourself_vs_first_person_by_type | "As yourself" vs plain first person, by scenario type |

## Numbers behind the profile figures (change in lie % from baseline)

Points (fig5a):

| model | first_person | first_person_self | hyperactive | anglo_saxon | latinate | control_format |
|---|---|---|---|---|---|---|
| Claude Haiku 5.5† | +1.2 | -2.4 | +1.8 | +1.8 | +1.2 | +1.2 |
| DeepSeek V4.1 Flash | +8.2 | -18.8 | +24.7 | +17.6 | +26.9 | +18.1 |
| GLM-5.3 | +1.2 | -6.1 | +5.5 | +3.7 | +10.4 | +7.3 |
| GLM-5.3-flash | +4.1 | -10.1 | +2.4 | +10.0 | +19.3 | +8.9 |
| Gemma 4 31B | +2.6 | -10.5 | +1.3 | +9.0 | +9.6 | +7.7 |
| Llama-3.1-8B | +8.9 | -0.6 | +6.9 | +9.4 | +5.1 | +3.2 |
| gpt-oss-120b | +0.6 | -2.6 | +2.6 | +5.2 | +11.1 | +9.1 |
| pooled (7) | +3.8 | -7.3 | +6.4 | +8.1 | +12.0 | +7.9 |

Relative to baseline (fig5b):

| model | first_person | first_person_self | hyperactive | anglo_saxon | latinate | control_format |
|---|---|---|---|---|---|---|
| Claude Haiku 5.5† | ×1.25 | ×0.56 | ×1.33 | ×1.33 | ×1.22 | ×1.20 |
| DeepSeek V4.1 Flash | ×1.21 | ×0.52 | ×1.61 | ×1.44 | ×1.67 | ×1.45 |
| GLM-5.3 | ×1.07 | ×0.64 | ×1.32 | ×1.21 | ×1.61 | ×1.43 |
| GLM-5.3-flash | ×1.21 | ×0.48 | ×1.12 | ×1.51 | ×1.97 | ×1.46 |
| Gemma 4 31B | ×1.04 | ×0.83 | ×1.02 | ×1.14 | ×1.16 | ×1.12 |
| Llama-3.1-8B | ×1.16 | ×0.99 | ×1.12 | ×1.17 | ×1.09 | ×1.06 |
| gpt-oss-120b | ×1.03 | ×0.88 | ×1.12 | ×1.24 | ×1.51 | ×1.42 |
| pooled (7) | ×1.12 | ×0.76 | ×1.20 | ×1.26 | ×1.38 | ×1.25 |

## Numbers behind the by-type figures (pooled across 7 models)

Plain first person vs baseline (fig3):

| scenario type | pooled change (pts) | 95% CI | pairs |
|---|---|---|---|
| provided_facts | +6.5 | +2.6 to +10.7 | 385 |
| known_facts | +2.2 | -2.6 to +7.3 | 232 |
| continuations | +1.0 | -3.9 to +5.8 | 208 |
| disinformation | +3.6 | -1.2 to +8.5 | 165 |
| doubling_down_known_facts | +3.9 | -2.3 to +10.0 | 130 |

"As yourself" vs baseline (fig4):

| scenario type | pooled change (pts) | 95% CI | pairs |
|---|---|---|---|
| provided_facts | -3.4 | -7.8 to +1.0 | 383 |
| known_facts | -6.5 | -12.1 to -0.9 | 231 |
| continuations | -8.4 | -13.5 to -3.7 | 215 |
| disinformation | -15.7 | -21.7 to -10.2 | 166 |
| doubling_down_known_facts | -7.9 | -15.0 to -0.8 | 127 |

"As yourself" vs plain first person (fig4b):

| scenario type | pooled change (pts) | 95% CI | pairs |
|---|---|---|---|
| provided_facts | -9.9 | -14.1 to -5.7 | 383 |
| known_facts | -9.1 | -14.7 to -3.5 | 232 |
| continuations | -8.2 | -13.0 to -3.4 | 208 |
| disinformation | -19.4 | -26.1 to -13.3 | 165 |
| doubling_down_known_facts | -12.4 | -19.4 to -5.4 | 129 |

## Combined three-condition view (fig6_three_conditions_by_type)

Lie % pooled across the 7 models:

| scenario type | baseline | plain first person | as yourself |
|---|---|---|---|
| All scenario types | 31.3 | 34.9 | 23.7 |
| Provided facts | 29.1 | 35.6 | 25.3 |
| Known facts | 23.9 | 26.0 | 17.6 |
| Continuations | 40.1 | 40.3 | 31.3 |
| Disinformation | 33.5 | 37.3 | 17.9 |
| Doubling down | 33.8 | 37.1 | 24.8 |

Per-model values are in `fig6_three_conditions_by_type.csv`.

## "Whose I" slope chart (fig7_whose_I_slope)

Lie %, on prompts scored in all three conditions:

| model | baseline | plain first person | as yourself | prompts |
|---|---|---|---|---|
| Gemma 4 31B | 61.2 | 65.1 | 50.7 | 152 |
| GLM-5.3-flash | 19.8 | 24.6 | 9.6 | 167 |
| GLM-5.3 | 16.7 | 17.9 | 11.1 | 162 |
| DeepSeek V4.1 Flash | 38.6 | 46.8 | 20.3 | 158 |
| gpt-oss-120b | 21.4 | 22.1 | 18.8 | 154 |
| Llama-3.1-8B | 56.4 | 65.4 | 55.8 | 156 |
| Claude Haiku 5.5† | 4.3 | 5.6 | 3.1 | 161 |
| pooled | 30.8 | 35.0 | 23.8 | 1110 |

Pooled changes (exact McNemar, all 7 models): baseline → plain "I" +3.8 (p = 9e-4); plain "I" → as yourself −11.1 (p = 1e-19); baseline → as yourself −7.3 (p = 4e-9). The −7.3 and −11.1 are both correct; they measure from different starting points.
