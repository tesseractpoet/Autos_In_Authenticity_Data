import pandas as pd, sys
from scipy.stats import binomtest
A='/home/claude/analysis/'
ms=sys.argv[1:]
C=[('baseline','first_person'),('baseline','first_person_self'),('first_person','first_person_self'),('baseline','hyperactive'),('baseline','anglo_saxon'),('baseline','latinate'),('baseline','control_format'),('anglo_saxon','latinate')]
rows=[]
for a,b in C:
    B=Cc=0; per={}
    tot=0; da=0
    for m in ms:
        d=pd.read_csv(A+f'{m}_judged.csv'); d=d[d.label.isin(['honest','lie','evade'])&(~d['empty'].astype(bool))]
        p=d.pivot_table(index='prompt_id',columns='condition',values='label',aggfunc='first')
        q=p[[a,b]].dropna(); la=(q[a]=='lie'); lb=(q[b]=='lie')
        per[m]=round(100*(lb.mean()-la.mean()),1); B+=int((la&~lb).sum()); Cc+=int((~la&lb).sum()); tot+=len(q)
    pv=binomtest(Cc,B+Cc,0.5).pvalue if B+Cc else 1
    rows.append(dict(contrast=f'{a} -> {b}',**per,pooled_pts=round(100*(Cc-B)/tot,1),pooled_p=f'{pv:.1g}'))
print(pd.DataFrame(rows).to_string(index=False))
