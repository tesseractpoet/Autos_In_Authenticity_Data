"""Word-origin lookup used by features.py (needs: pip install ety)."""
import re

LATINATE = ("Latin", "French", "Anglo-Norman", "Italian", "Spanish", "Portuguese",
            "Occitan", "Provençal")
GERMANIC = ("Old English", "Old Norse", "Germanic", "Dutch", "Saxon", "High German",
            "Low German", "Frisian", "Danish", "Swedish", "Norwegian", "Icelandic",
            "Gothic")
GREEK = ("Greek",)
SUFFIX = re.compile(r"(tion|sion|ity|ize|ise|ate|ous|ment|ance|ence|ive|ure|ible|"
                    r"able|ary|ory|ical)$")
_cache = {}


def origin(lemma):
    """'latinate', 'germanic', 'greek', or 'unknown' for a lowercase lemma.

    Uses the Etymological WordNet data bundled with the `ety` package, tracing
    every ancestor; any Latin/Romance ancestor counts as Latinate (so early
    loans like "street" count too). Falls back to Latinate suffixes. About a
    third of everyday words come back unknown, and those lean Germanic, so
    compare conditions against each other rather than reading the ratio as
    an absolute.
    """
    if lemma in _cache:
        return _cache[lemma]
    if lemma.endswith("ly") and len(lemma) > 6:  # "prematurely" -> "premature"
        _cache[lemma] = origin(lemma[:-2])
        if _cache[lemma] != "unknown":
            return _cache[lemma]
    import ety
    try:
        names = [o.language.name for o in ety.origins(lemma, recursive=True)]
    except Exception:
        names = []
    has = lambda keys: any(k in n for n in names for k in keys)
    if has(LATINATE):
        r = "latinate"
    elif has(GREEK):
        r = "greek"
    elif has(GERMANIC):
        r = "germanic"
    elif len(lemma) > 5 and SUFFIX.search(lemma):
        r = "latinate"
    else:
        r = "unknown"
    _cache[lemma] = r
    return r
