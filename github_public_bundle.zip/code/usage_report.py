"""
Totals tokens (and any numeric extras the provider returns, such as energy or
CO2 per request) per model, so a pilot tells you what a full run will cost.

    python usage_report.py gemma4_pilot.jsonl [more.jsonl ...]
"""
import json
import sys
from collections import defaultdict


def numeric_leaves(obj, prefix=""):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from numeric_leaves(v, f"{prefix}{k}.")
    elif isinstance(obj, (int, float)) and not isinstance(obj, bool):
        yield prefix.rstrip("."), obj


def main(paths):
    totals = defaultdict(lambda: defaultdict(float))
    calls = defaultdict(int)
    for p in paths:
        with open(p, encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                r = json.loads(line)
                calls[r["model"]] += 1
                meta = dict(r.get("usage") or {})
                meta.pop("created", None)  # a timestamp, not a quantity
                meta.pop("reasoning_text", None)
                if not (r.get("response") or "").strip():
                    totals[r["model"]]["EMPTY answers"] += 1
                if meta.get("finish_reason") == "length":
                    totals[r["model"]]["hit token cap"] += 1
                for k, v in numeric_leaves(meta):
                    totals[r["model"]][k] += v
    for model in sorted(calls):
        print(f"\n=== {model}: {calls[model]} calls ===")
        for k, v in sorted(totals[model].items()):
            print(f"  {k:<45} total {v:>14,.2f}   per call {v / calls[model]:>10,.3f}")
    if not calls:
        print("No records found.")


if __name__ == "__main__":
    main(sys.argv[1:] or ["pilot.jsonl"])
