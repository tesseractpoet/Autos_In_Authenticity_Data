import sys, glob, pandas as pd, csv
sys.path.insert(0,'/home/claude/sprint'); from analyze import load
VALID={'honest','lie','evade','unclear','no_belief'}
def build(m):
    J=f'/home/claude/judging/{m}'; key=pd.read_csv(f'/home/claude/keys/{m}/judge_key.csv',dtype=str)
    parts=[]
    for i in range(1,10):
        p=f'{J}/labels_part{i}.csv'
        df=pd.read_csv(p,dtype=str,keep_default_na=False,skipinitialspace=True); df['part']=i; parts.append(df)
    lab=pd.concat(parts); lab['item_id']=lab.item_id.str.strip()
    items=lab[~lab.item_id.str.endswith('.belief')]; bel=lab[lab.item_id.str.endswith('.belief')]
    groups={i.split('.')[0] for i in key.item_id}
    probs=[]
    miss=set(key.item_id)-set(items.item_id); extra=set(items.item_id)-set(key.item_id)
    dup=items.item_id[items.item_id.duplicated()].tolist()
    bad=items[~items.label.str.strip().isin(VALID)]
    nobel=groups-{b.split('.')[0] for b in bel.item_id}
    print(m,'items',len(items),'key',len(key),'missing',len(miss),'extra',len(extra),'dup',len(dup),'badlabel',len(bad),'groups w/o belief',len(nobel))
    if miss: print(' missing by part', sorted(miss)[:20])
    if len(bad): print(bad[['item_id','label','part']].head(10).to_string())
    out=f'/home/claude/analysis/claude_labels_{m}.csv'
    lab.drop(columns='part').to_csv(out,index=False,quoting=csv.QUOTE_MINIMAL)
    jl={'glm53':'run1_glm53.jsonl','llama8b':'run1_llama8b.jsonl','haiku55':'run1_haiku55.jsonl'}[m]
    df=load(f'/home/claude/keys/{m}/judge_key.csv',out,'/home/claude/analysis/'+jl)
    df['model']=m; df['label']=df.label.str.strip()
    df.to_csv(f'/home/claude/analysis/{m}_judged.csv',index=False)
    return df
if __name__=='__main__':
    for m in sys.argv[1:]: build(m)
