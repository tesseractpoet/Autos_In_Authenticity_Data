"""
Downloads the MASK dataset as plain JSON lines, without the parquet library
(which some Windows security settings block). Uses only Python's standard
library and Hugging Face's dataset viewer API.

    $env:HF_TOKEN = "your hf_ token"      (an account that accepted MASK's terms)
    python fetch_mask.py

Writes MASK_json/<scenario type>/test.jsonl, in the same row order as the
original files, so the random sample matches the Kaggle run exactly. Then use
--mask-dir MASK_json with pilot_generate.py.
"""
import json
import os
import time
import urllib.parse
import urllib.request

SPLITS = ["provided_facts", "known_facts", "disinformation", "continuations",
          "doubling_down_known_facts"]
API = "https://datasets-server.huggingface.co/rows"


def get(params, token, tries=5):
    url = API + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    for attempt in range(tries):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.load(r)
        except Exception as e:
            if attempt == tries - 1:
                raise
            print(f"  retrying ({e})")
            time.sleep(3 * (attempt + 1))


def main():
    token = os.environ.get("HF_TOKEN")
    if not token:
        raise SystemExit('Set your token first:  $env:HF_TOKEN = "hf_..."')
    for split in SPLITS:
        rows, offset, total = [], 0, None
        while total is None or offset < total:
            data = get({"dataset": "cais/MASK", "config": split, "split": "test",
                        "offset": offset, "length": 100}, token)
            total = data["num_rows_total"]
            batch = sorted(data["rows"], key=lambda r: r["row_idx"])
            cut = [r["row_idx"] for r in batch if r.get("truncated_cells")]
            if cut:
                raise SystemExit(f"{split}: the viewer API truncated long text in "
                                 f"rows {cut}; use the Kaggle conversion instead")
            rows += [r["row"] for r in batch]
            offset += len(batch)
            if not batch:
                break
        os.makedirs(os.path.join("MASK_json", split), exist_ok=True)
        with open(os.path.join("MASK_json", split, "test.jsonl"), "w",
                  encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"{split}: {len(rows)} rows (expected {total})")


if __name__ == "__main__":
    main()
