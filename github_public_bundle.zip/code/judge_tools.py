"""
Blind judging helpers: turn generated responses into a judging sheet that
hides the condition, then merge the judge's labels back in.

    python judge_tools.py sheet pilot3.jsonl
        -> judge_sheet.md (or judge_sheet_part1.md, part2... past 150 items)
           + judge_key.csv
    python judge_tools.py merge judge_key.csv claude_labels.csv:claude gemini_labels.csv:gemini
        -> judged.csv, a summary per judge, agreement between the first two
           judges, disagreements.csv, and an asterisk count for items a judge
           graded from its own model family

The sheet groups responses by prompt (so the scenario, the proposition and the
model's neutral belief answers appear once), shuffles responses within each
group, and labels them only by an item ID. The key file maps IDs back to
model / prompt / condition; the judge doesn't see it.

Judging instructions live in judge_rubric.md (keep it next to this file);
they are copied into the top of every sheet, so any model can follow them.
Labels file format (CSV): item_id,label,misleading,note
"""
import csv
import json
import random
import re
import sys
from collections import defaultdict

import os

RUBRIC_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "judge_rubric.md")

# Model families, for flagging a judge that grades its own family
FAMILIES = {"claude": ("claude", "anthropic", "sonnet", "opus", "haiku", "fable"),
            "google": ("gemini", "gemma", "google", "argon"),
            "meta": ("llama", "meta"),
            "zhipu": ("glm", "z-ai", "zhipu"),
            "moonshot": ("kimi", "moonshot"),
            "qwen": ("qwen", "alibaba"),
            "openai": ("gpt", "openai", "o3", "o4")}


def family(name):
    n = (name or "").lower()
    return next((f for f, keys in FAMILIES.items() if any(k in n for k in keys)), n)


def pivotal(prop):
    m = re.search(r"<pivotal>(.*?)</pivotal>", prop or "")
    if not m:
        return prop, None, None
    a, b = (m.group(1).split("/") + [""])[:2]
    pre, post = prop[:m.start()], prop[m.end():]
    return prop, (pre + a + post).strip(), (pre + b + post).strip()


def sheet(paths, seed=7, max_items=150):
    recs = []
    for p in paths:
        with open(p, encoding="utf-8") as f:
            recs += [json.loads(l) for l in f if l.strip()]
    groups = defaultdict(lambda: {"pressure": [], "belief": []})
    for r in recs:
        groups[(r["model"], r["prompt_id"])][r["kind"]].append(r)

    rng = random.Random(seed)
    keys = list(groups)
    rng.shuffle(keys)
    rubric = open(RUBRIC_PATH, encoding="utf-8").read()
    parts, out, key_rows, n = [], [], [], 0
    for gi, (model, pid) in enumerate(keys, 1):
        g = groups[(model, pid)]
        if not g["pressure"]:
            continue
        if out and n >= max_items * (len(parts) + 1):
            parts.append(out)
            out = []
        r0 = g["pressure"][0]
        _, side_a, side_b = pivotal(r0["proposition"])
        out.append(f"---\n\n# Group {gi}  ({r0['split']})\n")
        out.append(f"**Scenario (system prompt, style instruction removed):**\n\n"
                   f"> {first_block(r0['system'])}\n")
        for u, a in r0.get("prior_turns") or []:
            out.append(f"**Earlier in the conversation:**\n\n> User: {quote(u)}\n>\n"
                       f"> AI (earlier answer, shown to the AI as its own): "
                       f"{quote(a)}\n")
        out.append(f"**User{' (final turn)' if r0.get('prior_turns') else ''}:** "
                   f"{r0['user']}\n")
        out.append(f"**Proposition:** A = {side_a}  |  B = {side_b}\n")
        if r0["split"] == "provided_facts":
            out.append(f"**Reference (provided_facts): the true side is** "
                       f"{r0['ground_truth']}\n")
        else:
            out.append(f"**Reference ({r0['split']}): the model's neutral belief "
                       "answers** (decide the belief in Step 1):\n")
            for b in sorted(g["belief"], key=lambda x: x["condition"]):
                q = ("follow-up" if b["condition"][:1] in ("2", "3")
                     else "main question")
                out.append(f"- ({q}) Q: {one_line(b['user'], 250)}\n  "
                           f"A: {head_tail(b['response'])}")
            if not g["belief"]:
                out.append("- (no belief answers available: label items no_belief)")
            out.append("")
        items = g["pressure"][:]
        rng.shuffle(items)
        for r in items:
            n += 1
            iid = f"{gi}.{items.index(r) + 1}"
            out.append(f"### Item {iid}\n\n{r['response'].strip()}\n")
            key_rows.append({"item_id": iid, "model": model, "prompt_id": pid,
                             "split": r["split"], "condition": r["condition"]})

    parts.append(out)
    names = (["judge_sheet.md"] if len(parts) == 1 else
             [f"judge_sheet_part{i}.md" for i in range(1, len(parts) + 1)])
    for name, body in zip(names, parts):
        with open(name, "w", encoding="utf-8") as f:
            f.write(rubric + "\n\n# The responses\n\n" + "\n".join(body))
    with open("judge_key.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(key_rows[0]))
        w.writeheader()
        w.writerows(key_rows)
    print(f"Wrote {', '.join(names)} ({n} responses in {len(keys)} groups) and "
          f"judge_key.csv. Give the judge only the sheet(s); each part is "
          f"self-contained (instructions included).")


def first_block(system):
    # the style instruction is always appended after a blank line
    parts = (system or "").split("\n\nStyle requirement:")
    return parts[0].replace("\n", "\n> ")


def quote(text):
    return (text or "").strip().replace("\n", "\n> ")


def head_tail(text, head=250, tail=350):
    """Shorten long answers but keep the end, where the final answer usually is."""
    t = " ".join((text or "").split())
    return t if len(t) <= head + tail + 20 else t[:head] + " … " + t[-tail:]


def one_line(text, limit=400):
    t = " ".join((text or "").split())
    return t if len(t) <= limit else t[:limit] + " …"


def merge(key_path, judge_specs):
    """judge_specs: list of 'labels.csv:judgename' strings."""
    import pandas as pd
    pd.set_option("display.width", 250)
    pd.set_option("display.max_columns", 20)
    df = pd.read_csv(key_path, dtype=str)
    judges = []
    for spec in judge_specs:
        path, _, name = spec.partition(":")
        name = name or os.path.splitext(os.path.basename(path))[0]
        lab = pd.read_csv(path, dtype=str, skipinitialspace=True)
        lab = lab[~lab["item_id"].str.endswith(".belief")]
        lab = lab.rename(columns={"label": f"label_{name}",
                                  "misleading": f"misleading_{name}",
                                  "note": f"note_{name}"})
        df = df.merge(lab, on="item_id", how="left")
        df[f"own_family_{name}"] = df["model"].map(family) == family(name)
        judges.append(name)
    df.to_csv("judged.csv", index=False)

    for name in judges:
        col = f"label_{name}"
        print(f"\n=== judge: {name} ===")
        print(pd.crosstab([df["model"], df["condition"]], df[col].fillna("missing")))
        own = df[f"own_family_{name}"]
        if own.any():
            print(f"* {own.sum()} items were judged by their own model family "
                  f"({name}): report these with an asterisk.")
    if len(judges) >= 2:
        a, b = (f"label_{j}" for j in judges[:2])
        both = df[a].notna() & df[b].notna()
        agree = (df.loc[both, a] == df.loc[both, b]).mean()
        print(f"\nAgreement {judges[0]} vs {judges[1]}: {agree:.0%} of "
              f"{both.sum()} items")
        try:
            from sklearn.metrics import cohen_kappa_score
            k = cohen_kappa_score(df.loc[both, a], df.loc[both, b])
            print(f"Cohen's kappa: {k:.2f}")
        except ImportError:
            pass
        dis = df[both & (df[a] != df[b])]
        if len(dis):
            dis.to_csv("disagreements.csv", index=False)
            print(f"Wrote disagreements.csv ({len(dis)} items to review)")
    print("\nWrote judged.csv")


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "sheet":
        sheet(sys.argv[2:])
    elif len(sys.argv) >= 4 and sys.argv[1] == "merge":
        merge(sys.argv[2], sys.argv[3:])
    else:
        print(__doc__)
