"""
Rough feature counter for the pilot (and later the full run).

Reads the JSONL from pilot_generate.py, parses each pressure-prompt response
with spaCy, and writes:
  features.csv  one row per response, with the feature rates
  flagged.csv   every sentence counted as inanimate_agent ("the hills watch"),
                inanimate_evidential ("the data suggests"), ai_subject
                ("the model believes"), or passive / passive_agentless,
                for hand-checking
and prints average rates per model x condition.

Setup (once):
    pip install spacy nltk pandas ety
    python -m spacy download en_core_web_sm
    python -c "import nltk; nltk.download('wordnet')"

Run:
    python features.py pilot.jsonl                    # fast, rough (pilot)
    python features.py pilot.jsonl en_core_web_trf    # slower, more accurate

The small parser sometimes misreads tricky sentences ("The docstring
promises..." comes out as a noun phrase), so use en_core_web_trf for the real
run:  pip install spacy[transformers]  then  python -m spacy download en_core_web_trf
"""
import json
import sys

import pandas as pd
import spacy
from nltk.corpus import wordnet as wn

try:  # word origins: pip install ety  (etym.py must sit next to this file)
    from etym import origin
except ImportError:
    origin = None
    print("note: `ety` or etym.py not found, skipping Latinate/Germanic counts")

FIRST_PERSON = {"i", "me", "my", "mine", "myself"}
# Hedges are split: first-person hedges overlap with the first-person
# instruction itself, impersonal ones don't.
HEDGE_WORDS = {"might", "may", "perhaps", "possibly", "likely", "unlikely",
               "probably", "maybe", "arguably", "apparently", "seemingly"}
HEDGE_PHRASES_IMPERSONAL = ["it seems", "it appears"]
HEDGE_PHRASES_FIRST_PERSON = ["i think", "i believe", "not sure", "i'm not certain",
                              "to my knowledge", "i suspect", "i'd guess"]

ANIMATE_PRONOUNS = {"i", "you", "he", "she", "we", "me", "him", "her", "us",
                    "who", "someone", "somebody", "everyone", "anyone"}
INANIMATE_PRONOUNS = {"this", "that", "these", "those", "which", "something",
                      "everything", "nothing", "anything"}
# WordNet files "data", "series" etc. under noun.group, so a group noun only
# counts as human when it is on this list.
HUMAN_GROUPS = {"team", "company", "committee", "government", "family", "staff",
                "board", "group", "organization", "people", "crowd", "public",
                "community", "audience", "council", "agency", "firm", "party",
                "panel", "jury", "court", "management", "administration",
                "department", "union", "class", "society", "user", "customer"}
# Verbs where a document/data subject is conventional human usage
# ("the study found", "the data suggests"). Counted as their own feature.
EVIDENTIAL = {"suggest", "show", "indicate", "demonstrate", "reveal", "confirm",
              "prove", "imply", "support", "say", "state", "note", "report",
              "find", "establish", "highlight", "underscore", "illustrate",
              "describe", "detail", "outline", "mention", "cite", "explain",
              "document", "list"}
ANIMATE_VERB_FILES = {"verb.cognition", "verb.communication", "verb.perception",
                      "verb.emotion"}
ANIMATE_VERB_LIST = {"promise", "ask", "want", "know", "decide", "insist", "refuse",
                     "watch", "answer", "notice", "hope", "believe", "think", "feel",
                     "admit", "agree", "argue", "claim", "deny", "fear", "invite",
                     "love", "prefer", "pretend", "remember", "forget", "try", "wait",
                     "wish", "worry", "welcome", "whisper", "smile", "listen", "hear",
                     "see", "understand", "care", "trust", "expect", "intend",
                     "choose", "demand", "warn", "urge", "beg"}
# Verbs that only count as agent-like when they take a direct object:
# "the room holds the noise" counts, "the rule holds" doesn't.
NEEDS_OBJECT = {"hold"}
# Raising / linking verbs ("it seems", "it appears", "it looks like") aren't
# agent-like even with an "it" subject.
NEVER_AGENT = {"seem", "appear", "look", "sound", "feel", "remain", "become",
               "mean", "leak"}  # "this means"; "the pipeline leaked" (WordNet's
                                # first sense of leak is "tell anonymously")
# Nouns an AI might use to refer to itself in the third person
# ("the model believes", "this assistant cannot"). Counted separately,
# since whether they're "animate" is exactly the open question.
AI_NOUNS = {"model", "assistant", "ai", "system", "chatbot", "llm", "bot"}


RELATIVE_PRONOUNS = {"that", "which", "who", "whom"}


def antecedent(tok):
    """For "the pipeline that leaked", return "pipeline" instead of "that"."""
    verb = tok.head
    if tok.lower_ in RELATIVE_PRONOUNS and verb.dep_ in ("relcl", "acl:relcl"):
        return verb.head
    return tok


def subject_animacy(tok, ents_person):
    """Return 'animate', 'inanimate', 'ai', or None (unknown / skip)."""
    tok = antecedent(tok)
    low = tok.lower_
    if low == "it":
        return None  # "it seems", "it's worth noting": ordinary human speech
    if tok.pos_ == "PRON":
        if low in ANIMATE_PRONOUNS:
            return "animate"
        if low in INANIMATE_PRONOUNS:
            return "inanimate"
        return None  # "they" etc.: ambiguous
    if tok.i in ents_person:
        return "animate"
    if tok.pos_ == "PROPN" or tok.ent_type_ in {"ORG", "GPE", "NORP"}:
        return None  # "Google announced": metonymy, skip
    if tok.pos_ != "NOUN":
        return None
    lemma = tok.lemma_.lower()
    if lemma in AI_NOUNS:
        return "ai"
    if lemma in HUMAN_GROUPS:
        return "animate"
    # skip proper-name senses ("Hill" the person) and look at the top 3
    syns = [s for s in wn.synsets(lemma, pos=wn.NOUN) if not s.instance_hypernyms()]
    files = [s.lexname() for s in syns[:3]]
    if any(f in ("noun.person", "noun.animal") for f in files):
        return "animate"
    return "inanimate"  # includes words WordNet doesn't know ("docstring")


def verb_class(verb):
    lemma = verb.lemma_.lower()
    if lemma in NEVER_AGENT and lemma != "feel":
        return None
    if lemma in NEEDS_OBJECT:
        has_obj = any(c.dep_ in ("dobj", "obj") for c in verb.children)
        return "animate" if has_obj else None
    if lemma in EVIDENTIAL:
        return "evidential"
    if lemma in ANIMATE_VERB_LIST:
        return "animate"
    syns = wn.synsets(lemma, pos=wn.VERB)
    if syns and syns[0].lexname() in ANIMATE_VERB_FILES:
        return "animate"
    return None


def analyze(doc):
    words = [t for t in doc if t.is_alpha]
    sents = list(doc.sents)
    n_w, n_s = max(len(words), 1), max(len(sents), 1)
    ents_person = {t.i for e in doc.ents if e.label_ == "PERSON" for t in e}

    fp = sum(t.lower_ in FIRST_PERSON for t in words)
    text_low = doc.text.lower().replace("\u2019", "'")
    hedges_imp = sum(t.lower_ in HEDGE_WORDS for t in words) + sum(
        text_low.count(p) for p in HEDGE_PHRASES_IMPERSONAL)
    hedges_fp = sum(text_low.count(p) for p in HEDGE_PHRASES_FIRST_PERSON)

    # Passives: any "be/get + past participle" verb (marked by an auxpass
    # child), split by whether a "by ___" agent is given.
    passives_all, passives_agentless, passive_flags = 0, 0, []
    for t in doc:
        aux = [c for c in t.children if c.dep_ in ("auxpass", "aux:pass")]
        if not aux or t.lemma_ == "be":  # "there's been a misunderstanding"
            continue
        # "he's spoken" = "he has spoken"; the small parser sometimes reads the
        # 's as "is" and calls it passive.
        subj = [c.lower_ for c in t.children if c.dep_ in ("nsubjpass", "nsubj")]
        if aux[0].lower_ in ("'s", "\u2019s") and set(subj) & {"he", "she"}:
            continue
        if aux[0].lower_ == "being" and t.lemma_ == "say":  # "that being said"
            continue
        if True:
            passives_all += 1
            has_agent = any(c.dep_ == "agent" for c in t.children)
            if not has_agent:
                passives_agentless += 1
            passive_flags.append({"type": "passive" if has_agent else "passive_agentless",
                                  "subject": "", "verb": t.lemma_,
                                  "sentence": t.sent.text.strip()})
    deps = [abs(t.i - t.head.i) for t in doc if t.dep_ not in ("ROOT", "punct")]

    inan_agent, inan_evid, ai_subj, flagged = 0, 0, 0, []
    for t in doc:
        if t.dep_ != "nsubj" or t.head.pos_ != "VERB":
            continue
        anim = subject_animacy(t, ents_person)
        vc = verb_class(t.head)
        if t.dep_ != "nsubj" or anim not in ("inanimate", "ai") or vc is None:
            continue
        if anim == "ai":
            ai_subj += 1
            kind = "ai_subject"
        elif vc == "animate":
            inan_agent += 1
            kind = "inanimate_agent"
        else:
            inan_evid += 1
            kind = "inanimate_evidential"
        flagged.append({"type": kind, "subject": antecedent(t).text,
                        "verb": t.head.lemma_, "sentence": t.sent.text.strip()})

    lat = ger = 0
    if origin is not None:
        for t in doc:
            if t.is_alpha and t.pos_ in ("NOUN", "VERB", "ADJ", "ADV"):
                o = origin(t.lemma_.lower())
                lat += o == "latinate"
                ger += o == "germanic"

    counts = {
        "c_latinate": lat, "c_germanic": ger,
        "c_words": len(words), "c_sents": len(sents), "c_first_person": fp,
        "c_hedges_impersonal": hedges_imp, "c_hedges_first_person": hedges_fp,
        "c_passive": passives_all, "c_agentless_passive": passives_agentless,
        "c_inanimate_agent": inan_agent, "c_inanimate_evidential": inan_evid,
        "c_ai_subject": ai_subj,
    }
    feats = {
        "n_words": len(words),
        "n_sents": len(sents),
        "first_person_per_1k_words": 1000 * fp / n_w,
        "hedges_impersonal_per_1k_words": 1000 * hedges_imp / n_w,
        "hedges_first_person_per_1k_words": 1000 * hedges_fp / n_w,
        "passive_per_1k_sents": 1000 * passives_all / n_s,
        "agentless_passive_per_1k_sents": 1000 * passives_agentless / n_s,
        "inanimate_agent_per_1k_sents": 1000 * inan_agent / n_s,
        "inanimate_evidential_per_1k_sents": 1000 * inan_evid / n_s,
        "ai_subject_per_1k_sents": 1000 * ai_subj / n_s,
        "mean_dep_length": sum(deps) / len(deps) if deps else 0.0,
    }
    return {**feats, **counts}, flagged + passive_flags


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "pilot.jsonl"
    model_name = sys.argv[2] if len(sys.argv) > 2 else "en_core_web_sm"
    nlp = spacy.load(model_name)

    with open(path, encoding="utf-8") as f:
        recs = [json.loads(l) for l in f if l.strip()]
    recs = [r for r in recs if r["kind"] == "pressure" and r.get("response")]

    rows, flags = [], []
    for r, doc in zip(recs, nlp.pipe((r["response"] for r in recs), batch_size=16)):
        feats, flagged = analyze(doc)
        meta = {k: r[k] for k in ("model", "prompt_id", "split", "condition")}
        rows.append({**meta, **feats})
        flags += [{**meta, **fl} for fl in flagged]

    out = pd.DataFrame(rows)
    out.to_csv("features.csv", index=False)
    pd.DataFrame(flags).to_csv("flagged.csv", index=False)

    # Pooled rates: total count / total words (or sentences) per group, so a
    # one-word reply ("No.") can't swing the average the way it would if we
    # averaged each response's own rate.
    g = out.groupby(["model", "condition"])
    per_word = ["first_person", "hedges_impersonal", "hedges_first_person"]
    per_sent = ["passive", "agentless_passive", "inanimate_agent",
                "inanimate_evidential", "ai_subject"]
    summary = pd.DataFrame({"responses": g.size(),
                            "mean_words": g["c_words"].mean()})
    for f in per_word:
        summary[f + "/1k_words"] = 1000 * g[f"c_{f}"].sum() / g["c_words"].sum()
    for f in per_sent:
        summary[f + "/1k_sents"] = 1000 * g[f"c_{f}"].sum() / g["c_sents"].sum()
    if origin is not None:
        known = g["c_latinate"].sum() + g["c_germanic"].sum()
        summary["latinate_share_%"] = 100 * g["c_latinate"].sum() / known
    pd.set_option("display.width", 250)
    pd.set_option("display.max_columns", 20)
    print(summary.round(1).T)
    print(f"\nWrote features.csv ({len(out)} responses) and flagged.csv "
          f"({len(flags)} flagged sentences to hand-check).")


if __name__ == "__main__":
    main()
