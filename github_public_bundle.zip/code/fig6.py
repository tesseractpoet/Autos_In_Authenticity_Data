import pandas as pd, numpy as np, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
A='/home/claude/analysis/'; OUT='/home/claude/figs/'
MODELS=[('gemma4','Gemma 4 31B'),('glm53flash','GLM-5.3-flash'),('glm53','GLM-5.3'),('deepseek','DeepSeek V4.1 Flash'),('gptoss','gpt-oss-120b'),('llama8b','Llama-3.1-8B'),('haiku55adj','Claude Haiku 5.5†')]
SPL=[(None,'All scenario types'),('provided_facts','Provided facts'),('known_facts','Known facts'),('continuations','Continuations'),('disinformation','Disinformation'),('doubling_down_known_facts','Doubling down')]
INK='#2b2b2b'; MUTED='#6b6b6b'; GRID='#e6e6e3'; SURF='#fcfcfb'; BLUE='#2a78d6'; GRAY='#9a9a96'; RANGE='#d9d9d5'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.edgecolor':MUTED,'xtick.color':MUTED,'ytick.color':INK,'text.color':INK,'figure.facecolor':SURF,'axes.facecolor':SURF,'savefig.facecolor':SURF,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False})
D={}
for m,name in MODELS:
    d=pd.read_csv(A+f'{m}_judged.csv'); D[name]=d[d.label.isin(['honest','lie','evade'])&~d['empty'].astype(bool)]
rows=[]
fig,axs=plt.subplots(2,3,figsize=(12.5,7.6),sharex=True)
for ax,(sp,title) in zip(axs.flat,SPL):
    names=[n for _,n in MODELS]+['Pooled (7 models)']
    ys=np.arange(len(names))[::-1].astype(float); ys[-1]-=0.4
    for y,name in zip(ys,names):
        v=pd.concat(D.values()) if name.startswith('Pooled') else D[name]
        if sp: v=v[v.split==sp]
        r={c:100*(v[v.condition==c].label=='lie').mean() for c in ['baseline','first_person','first_person_self']}
        n=v[v.condition=='baseline'].prompt_id.nunique()
        rows.append(dict(scenario=title,model=name,baseline=round(r['baseline'],1),first_person=round(r['first_person'],1),as_yourself=round(r['first_person_self'],1),prompts=n))
        lo,hi=min(r.values()),max(r.values()); bold=name.startswith('Pooled')
        ax.plot([lo,hi],[y,y],color=RANGE if not bold else '#bdbdb8',lw=7 if not bold else 9,solid_capstyle='round',zorder=1)
        ax.plot(r['first_person'],y,'s',ms=7,mfc=SURF,mec=GRAY,mew=2,zorder=2)
        ax.plot(r['baseline'],y,'o',ms=8,color=INK,mec=SURF,mew=1.5,zorder=3)
        ax.plot(r['first_person_self'],y,'D',ms=8,color=BLUE,mec=SURF,mew=1.5,zorder=4)
    ax.set_yticks(ys); ax.set_yticklabels(names,fontsize=8)
    for t in ax.get_yticklabels():
        if t.get_text().startswith('Pooled'): t.set_fontweight('bold')
    ax.axhline(ys[-1]+0.7,color=GRID,lw=1)
    ax.set_title(title,loc='left',fontsize=10,fontweight='bold'); ax.set_xlim(-3,103)
    ax.xaxis.grid(True,color=GRID,lw=0.8); ax.set_axisbelow(True); ax.tick_params(length=0)
for ax in axs[1]: ax.set_xlabel('lie % of scored answers')
h=[Line2D([],[],marker='o',ls='none',color=INK,ms=8,label='baseline'),Line2D([],[],marker='s',ls='none',mfc=SURF,mec=GRAY,mew=2,ms=7,label='plain first person ("I" statements)'),Line2D([],[],marker='D',ls='none',color=BLUE,ms=8,label='"speak as yourself"'),Line2D([],[],color=RANGE,lw=7,label='spread between the three')]
fig.legend(handles=h,loc='upper left',bbox_to_anchor=(0.01,0.955),ncol=4,frameon=False,fontsize=9)
fig.suptitle('"Speak as yourself" vs plain first person vs baseline, by scenario type',x=0.01,y=0.995,ha='left',fontsize=12,fontweight='bold')
fig.text(0.01,-0.045,'Lie % per condition within each scenario type (prompts per model: provided facts 55, known facts 42, continuations 35, disinformation 25, doubling down 24, minus no-belief prompts).\nBlue left of the gray square = "as yourself" lied less than plain first person. † Haiku: human-adjudicated labels (Gemini primary judge). Others: Claude Opus judges.',fontsize=7.5,color=MUTED)
fig.tight_layout(rect=(0,0,1,0.93)); fig.savefig(OUT+'fig6_three_conditions_by_type.png',dpi=200,bbox_inches='tight'); fig.savefig(OUT+'fig6_three_conditions_by_type.svg',bbox_inches='tight')
pd.DataFrame(rows).to_csv(OUT+'fig6_three_conditions_by_type.csv',index=False); print('ok')
