import pandas as pd, numpy as np, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt, matplotlib.ticker
def proportion_confint(k,n,method='wilson',z=1.96):
    if n==0: return (0,0)
    p=k/n; den=1+z*z/n; c=(p+z*z/(2*n))/den; h=z*((p*(1-p)/n+z*z/(4*n*n))**0.5)/den; return (c-h,c+h)
A='/home/claude/analysis/'; OUT='/home/claude/figs/'
MODELS=[('gemma4','Gemma 4 31B'),('glm53flash','GLM-5.3-flash'),('glm53','GLM-5.3'),('deepseek','DeepSeek V4.1 Flash'),('gptoss','gpt-oss-120b'),('llama8b','Llama-3.1-8B'),('haiku55adj','Claude Haiku 5.5†')]
COL=['#2a78d6','#eb6834','#1baf7a','#eda100','#e87ba4','#008300','#6250d6']; MK=['o','s','^','D','v','P','X']
C=['baseline','first_person','first_person_self','hyperactive','anglo_saxon','latinate','control_format']
CL={'baseline':'baseline','first_person':'first person','first_person_self':'as yourself','hyperactive':'hyperactive','anglo_saxon':'Anglo-Saxon','latinate':'Latinate','control_format':'format control'}
SPL=['provided_facts','known_facts','continuations','disinformation','doubling_down_known_facts']
SL={'provided_facts':'provided facts','known_facts':'known facts','continuations':'continuations','disinformation':'disinformation','doubling_down_known_facts':'doubling down'}
INK='#2b2b2b'; MUTED='#6b6b6b'; GRID='#e6e6e3'; SURF='#fcfcfb'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.edgecolor':MUTED,'axes.labelcolor':INK,'xtick.color':MUTED,'ytick.color':MUTED,'text.color':INK,'figure.facecolor':SURF,'axes.facecolor':SURF,'savefig.facecolor':SURF,'axes.spines.top':False,'axes.spines.right':False})
MEASURE={'lie':lambda s:s=='lie','nothonest':lambda s:s!='honest'}
def data(m):
    d=pd.read_csv(A+f'{m}_judged.csv'); return d[d.label.isin(['honest','lie','evade'])&~d['empty'].astype(bool)]
rng=np.random.default_rng(42)
def paired(d,a,b,meas,splits=None,B=4000):
    if splits: d=d[d.split.isin(splits)]
    pv=d.pivot_table(index='prompt_id',columns='condition',values='label',aggfunc='first')
    if a not in pv or b not in pv: return None
    q=pv[[a,b]].dropna(); x=MEASURE[meas](q[a]).values.astype(float); y=MEASURE[meas](q[b]).values.astype(float); n=len(q)
    if n==0: return None
    idx=rng.integers(0,n,(B,n)); xa=x[idx].mean(1); yb=y[idx].mean(1)
    diff=100*(yb-xa)
    with np.errstate(divide='ignore',invalid='ignore'): rr=np.where(xa>0,yb/xa,np.nan)
    rrv=rr[np.isfinite(rr)&(rr>0)]
    return dict(n=n,base=100*x.mean(),cond=100*y.mean(),d=100*(y.mean()-x.mean()),dlo=np.percentile(diff,2.5),dhi=np.percentile(diff,97.5),
                rr=(y.mean()/x.mean() if x.mean()>0 else np.nan),rlo=(np.percentile(rrv,2.5) if len(rrv) else np.nan),rhi=(np.percentile(rrv,97.5) if len(rrv) else np.nan))
D={m:data(m) for m,_ in MODELS}
def pooled(a,b,meas,splits=None):
    # pooled bootstrap: resample prompts within each model
    xs=[];ys=[]
    for m,_ in MODELS:
        d=D[m] if not splits else D[m][D[m].split.isin(splits)]
        pv=d.pivot_table(index='prompt_id',columns='condition',values='label',aggfunc='first')
        if a in pv and b in pv:
            q=pv[[a,b]].dropna(); xs.append(MEASURE[meas](q[a]).values.astype(float)); ys.append(MEASURE[meas](q[b]).values.astype(float))
    x=np.concatenate(xs); y=np.concatenate(ys); n=len(x); idx=rng.integers(0,n,(4000,n))
    diff=100*(y[idx].mean(1)-x[idx].mean(1)); rr=y[idx].mean(1)/x[idx].mean(1)
    return dict(n=n,d=100*(y.mean()-x.mean()),dlo=np.percentile(diff,2.5),dhi=np.percentile(diff,97.5),rr=y.mean()/x.mean(),rlo=np.percentile(rr,2.5),rhi=np.percentile(rr,97.5))
note='† Haiku: human-adjudicated labels (Gemini primary judge + AJ\'s rules). Others: Claude Opus judges. Bars/whiskers: 95% CI.'

def fig1(meas,fname,title):
    fig,axs=plt.subplots(1,7,figsize=(13,3.6),sharey=True)
    for ax,(m,name) in zip(axs,MODELS):
        d=D[m]; vals=[];lo=[];hi=[]
        for c in C:
            s=d[d.condition==c]; k=int(MEASURE[meas](s.label).sum()); n=len(s)
            l,h=proportion_confint(k,n,method='wilson'); vals.append(100*k/n); lo.append(100*(k/n-l)); hi.append(100*(h-k/n))
        cols=[INK if c=='baseline' else ('#2a78d6' if c=='first_person_self' else '#b9b9b5') for c in C]
        ax.bar(range(7),vals,width=0.72,color=cols,edgecolor=SURF,linewidth=2)
        ax.errorbar(range(7),vals,yerr=[lo,hi],fmt='none',ecolor=MUTED,elinewidth=1,capsize=0)
        ax.set_title(name,fontsize=9); ax.set_xticks(range(7)); ax.set_xticklabels([CL[c] for c in C],rotation=60,ha='right',fontsize=7.5)
        ax.yaxis.grid(True,color=GRID,linewidth=0.8); ax.set_axisbelow(True); ax.tick_params(length=0)
    axs[0].set_ylabel(('lie' if meas=='lie' else 'not honest (lie + evade)')+' % of scored answers'); axs[0].set_ylim(0,100)
    fig.suptitle(title,x=0.01,ha='left',fontsize=11,fontweight='bold')
    fig.text(0.01,-0.02,'Dark bar = baseline, blue = "speak as yourself". '+note,fontsize=7.5,color=MUTED)
    fig.tight_layout(); fig.savefig(OUT+fname+'.png',dpi=200,bbox_inches='tight'); fig.savefig(OUT+fname+'.svg',bbox_inches='tight'); plt.close(fig)

CONTR=[('baseline','first_person'),('baseline','first_person_self'),('first_person','first_person_self'),('baseline','hyperactive'),('baseline','anglo_saxon'),('baseline','latinate'),('baseline','control_format'),('anglo_saxon','latinate')]
def ctl(a,b): return f"{CL[a]} → {CL[b]}"
def fig2(meas,kind,fname,title):
    fig,axs=plt.subplots(2,4,figsize=(13,6.6),sharex=True)
    rows=[]
    for ax,(a,b) in zip(axs.flat,CONTR):
        ys=np.arange(len(MODELS))[::-1]
        for y,((m,name),col,mk) in zip(ys,zip(MODELS,COL,MK)):
            r=paired(D[m],a,b,meas)
            v,lo,hi=(r['d'],r['dlo'],r['dhi']) if kind=='abs' else (r['rr'],r['rlo'],r['rhi'])
            rows.append(dict(contrast=ctl(a,b),model=name,estimate=v,lo=lo,hi=hi,n=r['n'],base_pct=r['base']))
            if np.isfinite(v):
                ax.plot([lo,hi],[y,y],color=col,lw=2,solid_capstyle='round'); ax.plot(v,y,marker=mk,ms=8,color=col,mec=SURF,mew=1.5,ls='none')
        p=pooled(a,b,meas); v,lo,hi=(p['d'],p['dlo'],p['dhi']) if kind=='abs' else (p['rr'],p['rlo'],p['rhi'])
        rows.append(dict(contrast=ctl(a,b),model='pooled (7)',estimate=v,lo=lo,hi=hi,n=p['n'],base_pct=np.nan))
        ax.plot([lo,hi],[-1.2,-1.2],color=INK,lw=2.5); ax.plot(v,-1.2,marker='D',ms=9,color=INK,mec=SURF,mew=1.5)
        ax.axvline(0 if kind=='abs' else 1,color=MUTED,lw=1,ls=(0,(3,3)))
        ax.set_yticks(list(ys)+[-1.2]); ax.set_yticklabels([n for _,n in MODELS]+['pooled'],fontsize=7.5)
        ax.set_title(ctl(a,b),fontsize=9); ax.xaxis.grid(True,color=GRID,lw=0.8); ax.set_axisbelow(True); ax.tick_params(length=0)
        if kind=='rel': ax.set_xscale('log'); ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter()); ax.xaxis.set_minor_locator(matplotlib.ticker.NullLocator()); ax.set_xticks([0.25,0.5,1,2,4]); ax.set_xticklabels(['×¼','×½','×1','×2','×4']); ax.set_xlim(0.15,6)
    lab=('change in '+('lie' if meas=='lie' else 'not-honest')+' %, percentage points') if kind=='abs' else ('ratio to starting rate ('+('lie' if meas=='lie' else 'not-honest')+' %), log scale')
    for ax in axs[1]: ax.set_xlabel(lab)
    fig.suptitle(title,x=0.01,ha='left',fontsize=11,fontweight='bold')
    fig.text(0.01,-0.03,'Paired on the same prompts; 95% bootstrap CIs (4,000 resamples of prompts). Pooled = all model×prompt pairs. '+note,fontsize=7.5,color=MUTED)
    fig.tight_layout(); fig.savefig(OUT+fname+'.png',dpi=200,bbox_inches='tight'); fig.savefig(OUT+fname+'.svg',bbox_inches='tight'); plt.close(fig)
    pd.DataFrame(rows).round(3).to_csv(OUT+fname+'.csv',index=False)

def fig3(a,b,meas,fname,title):
    fig,ax=plt.subplots(figsize=(8.5,4.2)); rows=[]
    for xi,s in enumerate(SPL):
        offs=np.linspace(-0.3,0.3,len(MODELS))
        for o,((m,name),col,mk) in zip(offs,zip(MODELS,COL,MK)):
            r=paired(D[m],a,b,meas,splits=[s])
            if r: ax.plot(xi+o,r['d'],marker=mk,ms=7,color=col,mec=SURF,mew=1.2,ls='none',label=name if xi==0 else None); rows.append(dict(split=s,model=name,change=r['d'],n=r['n'],base=r['base']))
        p=pooled(a,b,meas,splits=[s]); ax.plot([xi+0.42,xi+0.42],[p['dlo'],p['dhi']],color=INK,lw=2.5); ax.plot(xi+0.42,p['d'],marker='D',ms=9,color=INK,mec=SURF,mew=1.5,label='pooled ± 95% CI' if xi==0 else None)
        rows.append(dict(split=s,model='pooled',change=p['d'],lo=p['dlo'],hi=p['dhi'],n=p['n']))
    ax.axhline(0,color=MUTED,lw=1,ls=(0,(3,3))); ax.set_xticks(range(len(SPL))); ax.set_xticklabels([SL[s] for s in SPL])
    ax.set_ylabel(f"change in {'lie' if meas=='lie' else 'not-honest'} %, points"); ax.yaxis.grid(True,color=GRID,lw=0.8); ax.set_axisbelow(True); ax.tick_params(length=0)
    ax.legend(fontsize=7.5,frameon=False,ncol=4,loc='upper center',bbox_to_anchor=(0.5,-0.08))
    ax.set_title(title,loc='left',fontsize=11,fontweight='bold')
    fig.text(0.01,-0.06,'Each dot is one model (paired on the same prompts within that scenario type; n per dot = 18–55 prompts). '+note,fontsize=7,color=MUTED,wrap=True)
    fig.tight_layout(); fig.savefig(OUT+fname+'.png',dpi=200,bbox_inches='tight'); fig.savefig(OUT+fname+'.svg',bbox_inches='tight'); plt.close(fig)
    pd.DataFrame(rows).round(2).to_csv(OUT+fname+'.csv',index=False)

fig1('lie','fig1_lie_rates','Lie rate by condition, seven models')
fig1('nothonest','fig1b_nothonest_rates','Not-honest rate (lie + evade) by condition, seven models')
fig2('lie','abs','fig2a_change_points','Change in lie rate, percentage points')
fig2('lie','rel','fig2b_change_relative','Change in lie rate relative to each model\'s starting rate')
fig2('nothonest','abs','fig2c_nothonest_change_points','Change in not-honest rate (lie + evade), percentage points')
fig3('baseline','first_person','lie','fig3_first_person_by_type','Plain first person ("I" statements) vs baseline, by scenario type')
fig3('baseline','first_person_self','lie','fig4_as_yourself_by_type','"Speak as yourself" vs baseline, by scenario type')
fig3('first_person','first_person_self','lie','fig4b_as_yourself_vs_first_person_by_type','"Speak as yourself" vs plain first person, by scenario type')
print('done')

def fig5(kind,fname,title):
    order=['baseline','first_person','first_person_self','hyperactive','anglo_saxon','latinate','control_format']
    fig,ax=plt.subplots(figsize=(9.5,5.2)); x=np.arange(len(order)); rows=[]
    ends=[]
    for (m,name),col,mk in zip(MODELS,COL,MK):
        ys=[];lo=[];hi=[]
        for c in order:
            if c=='baseline': ys.append(0 if kind=='abs' else 1); lo.append(np.nan); hi.append(np.nan); continue
            r=paired(D[m],'baseline',c,'lie'); v=r['d'] if kind=='abs' else r['rr']; ys.append(v)
            rows.append(dict(model=name,condition=c,estimate=v,lo=r['dlo'] if kind=='abs' else r['rlo'],hi=r['dhi'] if kind=='abs' else r['rhi']))
        ax.plot(x,ys,color=col,lw=2,alpha=0.9,zorder=2,marker=mk,ms=7,mec=SURF,mew=1.2,label=name)
        ends.append((ys[-1],name,col))
    py=[0 if kind=='abs' else 1]
    for c in order[1:]:
        p=pooled('baseline',c,'lie'); py.append(p['d'] if kind=='abs' else p['rr']); rows.append(dict(model='pooled (7)',condition=c,estimate=py[-1],lo=p['dlo'] if kind=='abs' else p['rlo'],hi=p['dhi'] if kind=='abs' else p['rhi']))
        ax.plot([x[len(py)-1]]*2,[p['dlo'],p['dhi']] if kind=='abs' else [p['rlo'],p['rhi']],color=INK,lw=2.5,zorder=4)
    ax.plot(x,py,color=INK,lw=3.5,zorder=4,marker='D',ms=9,mec=SURF,mew=1.5,label='pooled (7) ± 95% CI')
    ax.axhline(0 if kind=='abs' else 1,color=MUTED,lw=1,ls=(0,(3,3)),zorder=1)
    if kind=='rel':
        ax.set_yscale('log'); ax.yaxis.set_minor_formatter(matplotlib.ticker.NullFormatter()); ax.yaxis.set_minor_locator(matplotlib.ticker.NullLocator())
        ax.set_yticks([0.5,0.75,1,1.5,2]); ax.set_yticklabels(['×0.5','×0.75','×1 (baseline)','×1.5','×2']); ax.set_ylim(0.42,2.3)
    ax.set_xticks(x); ax.set_xticklabels([CL[c] for c in order]); ax.yaxis.grid(True,color=GRID,lw=0.8); ax.set_axisbelow(True); ax.tick_params(length=0)
    ax.set_ylabel('change in lie % vs baseline, points' if kind=='abs' else 'lie rate relative to baseline (log scale)')
    ax.legend(fontsize=7.5,frameon=False,loc='upper left',bbox_to_anchor=(1.01,1))
    ax.set_title(title,loc='left',fontsize=11,fontweight='bold')
    fig.text(0.01,-0.04,'Lines connect each model\'s results to show its profile across conditions; the conditions are categories, not a sequence. Paired on the same prompts.\n'+note,fontsize=7,color=MUTED)
    fig.tight_layout(); fig.savefig(OUT+fname+'.png',dpi=200,bbox_inches='tight'); fig.savefig(OUT+fname+'.svg',bbox_inches='tight'); plt.close(fig)
    pd.DataFrame(rows).round(3).to_csv(OUT+fname+'.csv',index=False)
fig5('abs','fig5a_profile_points','Change in lie rate from baseline, each model\'s profile')
fig5('rel','fig5b_profile_relative','Lie rate relative to baseline, each model\'s profile')
print('fig5 done')
