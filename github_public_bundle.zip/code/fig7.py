import pandas as pd, numpy as np, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
A='/home/claude/analysis/'; OUT='/home/claude/figs/'
MODELS=[('gemma4','Gemma 4 31B'),('glm53flash','GLM-5.3-flash'),('glm53','GLM-5.3'),('deepseek','DeepSeek V4.1 Flash'),('gptoss','gpt-oss-120b'),('llama8b','Llama-3.1-8B'),('haiku55adj','Claude Haiku 5.5†')]
COL=['#2a78d6','#eb6834','#1baf7a','#eda100','#e87ba4','#008300','#6250d6']; MK=['o','s','^','D','v','P','X']
INK='#2b2b2b'; MUTED='#6b6b6b'; GRID='#e6e6e3'; SURF='#fcfcfb'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.edgecolor':MUTED,'xtick.color':INK,'ytick.color':MUTED,'text.color':INK,'figure.facecolor':SURF,'axes.facecolor':SURF,'savefig.facecolor':SURF,'axes.spines.top':False,'axes.spines.right':False})
C=['baseline','first_person','first_person_self']
t=pd.read_csv('/home/claude/out/all7_paired_tests.csv'); t=t[(t.measure=='lie')&(t.model=='POOLED (7)')].set_index('contrast')
fig,ax=plt.subplots(figsize=(8.6,5.6)); x=np.arange(3); allv=[]; rows=[]; ends=[]
for (m,name),col,mk in zip(MODELS,COL,MK):
    d=pd.read_csv(A+f'{m}_judged.csv'); d=d[d.label.isin(['honest','lie','evade'])&~d['empty'].astype(bool)]
    pv=d.pivot_table(index='prompt_id',columns='condition',values='label',aggfunc='first')[C].dropna()
    ys=[100*(pv[c]=='lie').mean() for c in C]; allv.append(pv); rows.append(dict(model=name,**dict(zip(C,np.round(ys,1))),prompts=len(pv)))
    ax.plot(x,ys,color=col,lw=2,marker=mk,ms=7,mec=SURF,mew=1.2,alpha=0.9,label=name,zorder=2)
    ends.append([ys[2],name])
P=pd.concat(allv); py=[100*(P[c]=='lie').mean() for c in C]; rows.append(dict(model='pooled',**dict(zip(C,np.round(py,1))),prompts=len(P)))
ax.plot(x,py,color=INK,lw=4,marker='D',ms=10,mec=SURF,mew=1.5,zorder=4,label='pooled (7 models)')
ends.append([py[2],'pooled (7 models)'])
ends.sort(key=lambda e:e[0])
for i in range(1,len(ends)):
    if ends[i][0]-ends[i-1][0]<3.4: ends[i][0]=ends[i-1][0]+3.4
for yv,nm in ends: ax.text(2.1,yv,nm,va='center',fontsize=7.8,color=INK,fontweight='bold' if nm.startswith('pooled') else 'normal')
d1=t.loc['baseline -> first_person','change_pts']; d2=t.loc['first_person -> first_person_self','change_pts']; d3=t.loc['baseline -> first_person_self','change_pts']
ax.annotate(f"{d1:+.1f} pts",xy=(0.5,(py[0]+py[1])/2),xytext=(0.5,max(py)+9),ha='center',fontsize=9,fontweight='bold',arrowprops=dict(arrowstyle='-',color=MUTED,lw=0.8))
ax.annotate(f"{d2:+.1f} pts\n(p = 1e-19)",xy=(1.5,(py[1]+py[2])/2),xytext=(1.5,max(py)+9),ha='center',fontsize=9,fontweight='bold',color='#2a78d6',arrowprops=dict(arrowstyle='-',color=MUTED,lw=0.8))
ax.text(1,-9,f'baseline → as yourself: {d3:+.1f} pts (p = 4e-9)',ha='center',fontsize=8.5,color=INK)
ax.set_xticks(x); ax.set_xticklabels(['baseline','plain first person\n("I" statements)','"speak as yourself"']); ax.set_xlim(-0.25,2.85); ax.set_ylim(-12,80); ax.set_yticks([0,20,40,60,80])
ax.set_ylabel('lie % of scored answers'); ax.yaxis.grid(True,color=GRID,lw=0.8); ax.set_axisbelow(True); ax.tick_params(length=0)
ax.set_title('Whose "I"? Lie rate at baseline, with plain "I", and speaking as itself',loc='left',fontsize=11,fontweight='bold')
fig.text(0.01,-0.03,'Same prompts in all three conditions (paired). Pooled changes from exact McNemar tests on all 7 models. The step from plain "I" to "as yourself" is the minimal pair:\nthe "as yourself" instruction adds only one clause saying whose "I" it is (the AI model writing the reply, not a character). † Haiku: human-adjudicated labels (Gemini primary judge). Others: Claude Opus judges.',fontsize=7.2,color=MUTED)
fig.tight_layout(); fig.savefig(OUT+'fig7_whose_I_slope.png',dpi=200,bbox_inches='tight'); fig.savefig(OUT+'fig7_whose_I_slope.svg',bbox_inches='tight')
pd.DataFrame(rows).to_csv(OUT+'fig7_whose_I_slope.csv',index=False); print(py)
